package com.vehicle.project.model;

public class Vehicle {
    private int id;
    private String brand;
    private String model;
    private String year_made;


    public int getVehicle_id() {
        return id;
    }
    public void setVehicle_id(int id) {
        this.id = id;
    }
    public String getBrand() {
        return brand;
    }
    public void setBrand(String brand) {
        this.brand = brand;
    }
    public String getModel() {
        return model;
    }
    public void setModel(String model) {
        this.model = model;
    }
    public String getYear_made() {
        return year_made;
    }
    public void setYear_made(String year_made) {
        this.year_made = year_made;
    }
    

    
}
