package com.vehicle.project.mapper;

public class ServiceDeleteRowMapper {
    
}
